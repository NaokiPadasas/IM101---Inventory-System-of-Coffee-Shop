<?php 
require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array(), 'order_id' => '');

if($_POST) {	

	$orderDate 						= date('Y-m-d', strtotime($_POST['orderDate']));	
  $clientName 					= $_POST['clientName'];
  $clientContact 				= $_POST['clientContact'];
  $subTotalValue 				= $_POST['subTotalValue'];
  $vatValue 						=	$_POST['vatValue'];
  $totalAmountValue     = $_POST['totalAmountValue'];
  $discount 						= $_POST['discount'];
  $grandTotalValue 			= $_POST['grandTotalValue'];
  $paid 								= $_POST['paid'];
  $dueValue 						= $_POST['dueValue'];
  $paymentType 					= $_POST['paymentType'];
  $paymentStatus 				= $_POST['paymentStatus'];
  $paymentPlace 				= $_POST['paymentPlace'];
  $gstn 				= $_POST['gstn'];
  $userid 				= $_SESSION['userId'];

	// Start transaction to ensure atomicity
	$connect->begin_transaction();

	$sql = "INSERT INTO orders (order_date, client_name, client_contact, sub_total, vat, total_amount, discount, grand_total, paid, due, payment_type, payment_status, payment_place, gstn, order_status, user_id) 
	VALUES ('$orderDate', '$clientName', '$clientContact', '$subTotalValue', '$vatValue', '$totalAmountValue', '$discount', '$grandTotalValue', '$paid', '$dueValue', $paymentType, $paymentStatus, $paymentPlace, '$gstn', 1, $userid)";

	$orderStatus = false;
	$order_id = null;

	if($connect->query($sql) === true) {
		$order_id = $connect->insert_id;
		$valid['order_id'] = $order_id;
		$orderStatus = true;
	}

	$orderItemStatus = false;

	for($x = 0; $x < count($_POST['productName']); $x++) {			

		// Fetch the current stock of the product
		$updateProductQuantitySql = "SELECT product.quantity FROM product WHERE product.product_id = ".$_POST['productName'][$x];
		$updateProductQuantityData = $connect->query($updateProductQuantitySql);
		
		$productStock = 0;
		if($updateProductQuantityData->num_rows > 0) {
			$productStock = $updateProductQuantityData->fetch_row()[0];
		}

		// Check if the requested quantity is available
		$requestedQuantity = $_POST['quantity'][$x];
		if($requestedQuantity > $productStock) {
			// If the requested quantity is more than the available stock, stop the order process
			$valid['messages'] = "Not enough stock for product ID " . $_POST['productName'][$x];
			$connect->rollback(); // Rollback transaction
			echo json_encode($valid);
			exit; // Exit the script
		}

		// If there is enough stock, update the product quantity
		$updateQuantity = $productStock - $requestedQuantity;

		// Update the product stock in the database
		$updateProductTable = "UPDATE product SET quantity = '$updateQuantity' WHERE product_id = ".$_POST['productName'][$x];
		$connect->query($updateProductTable);

		// Add the order item to the order_item table
		$orderItemSql = "INSERT INTO order_item (order_id, product_id, quantity, rate, total, order_item_status) 
		VALUES ('$order_id', '".$_POST['productName'][$x]."', '$requestedQuantity', '".$_POST['rateValue'][$x]."', '".$_POST['totalValue'][$x]."', 1)";
		
		$connect->query($orderItemSql);

		if($x == count($_POST['productName']) - 1) {
			$orderItemStatus = true;
		}
	}

	// If everything went well, commit the transaction
	if ($orderStatus && $orderItemStatus) {
		$connect->commit();
		$valid['success'] = true;
		$valid['messages'] = "Order placed successfully.";
	} else {
		// In case of failure, rollback the transaction
		$connect->rollback();
		$valid['messages'] = "There was an error placing the order.";
	}

	$connect->close();
	echo json_encode($valid);

} // /if $_POST
?>
