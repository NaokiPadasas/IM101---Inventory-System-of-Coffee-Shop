<?php
// Include your DB configuration
require_once 'core.php';

// Check if the period is set and handle it
if (isset($_POST['period'])) {
    $period = $_POST['period']; // Get the selected period (daily, weekly, monthly, yearly)

    // Default: query for all periods
    $query = "";
    
    switch ($period) {
        case 'monthly':
            $query = "SELECT YEAR(order_date) AS year, MONTH(order_date) AS month, SUM(total_amount) AS total_sales
                      FROM orders
                      WHERE order_status = 1
                      GROUP BY YEAR(order_date), MONTH(order_date)
                      ORDER BY YEAR(order_date), MONTH(order_date)";
            break;
        
        case 'weekly':
            $query = "SELECT YEAR(order_date) AS year, WEEK(order_date) AS week, SUM(total_amount) AS total_sales
                      FROM orders
                      WHERE order_status = 1
                      GROUP BY YEAR(order_date), WEEK(order_date)
                      ORDER BY YEAR(order_date), WEEK(order_date)";
            break;
        
        case 'daily':
            $query = "SELECT DATE(order_date) AS day, SUM(total_amount) AS total_sales
                      FROM orders
                      WHERE order_status = 1
                      GROUP BY DATE(order_date)
                      ORDER BY DATE(order_date)";
            break;
        
        case 'yearly':
            $query = "SELECT YEAR(order_date) AS year, SUM(total_amount) AS total_sales
                      FROM orders
                      WHERE order_status = 1
                      GROUP BY YEAR(order_date)
                      ORDER BY YEAR(order_date)";
            break;
        
        default:
            // If no period selected, fallback to monthly
            $query = "SELECT YEAR(order_date) AS year, MONTH(order_date) AS month, SUM(total_amount) AS total_sales
                      FROM orders
                      WHERE order_status = 1
                      GROUP BY YEAR(order_date), MONTH(order_date)
                      ORDER BY YEAR(order_date), MONTH(order_date)";
            break;
    }

    // Execute the query and fetch the result
    $result = $connect->query($query);

    // Fetch data
    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    // Return data as JSON
    echo json_encode($data);
}
?>
