<?php 	

$localhost = "sql312.infinityfree.com";
$username = "if0_37583025";
$password = "m3BAvro7CT6u";
$dbname = "if0_37583025_coffee_shop_inventory";
$store_url = "http://localhost/SimpleInventorySystem-PHP/";
// db connection
$connect = new mysqli($localhost, $username, $password, $dbname);
// check connection
if($connect->connect_error) {
  die("Connection Failed : " . $connect->connect_error);
} else {
  // echo "Successfully connected";
}

?>