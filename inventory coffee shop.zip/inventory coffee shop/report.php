<?php require_once 'includes/header.php'; ?>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <i class="glyphicon glyphicon-check"></i> Order Report
            </div>
            <div class="panel-body">
                
                <form class="form-horizontal" action="php_action/getOrderReport.php" method="post" id="getOrderReportForm">
                    <div class="form-group">
                        <label for="period" class="col-sm-2 control-label">Period</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="period" name="period">
                                <option value="daily">Daily</option>
                                <option value="weekly">Weekly</option>
                                <option value="monthly" selected>Monthly</option>
                                <option value="yearly">Yearly</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="submit" class="btn btn-success" id="generateReportBtn"> <i class="glyphicon glyphicon-ok-sign"></i> Generate Report</button>
                        </div>
                    </div>
                </form>

                <!-- Graph for sales data -->
                <div class="mt-4">
                    <canvas id="salesChart"></canvas>
                </div>

            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
let salesChart = null; // Store the chart instance globally

// Month names array to convert month numbers to month names
const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];

// Handle form submission to get the report
document.getElementById('getOrderReportForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    var period = document.getElementById('period').value;

    // Make an AJAX request to get the sales data
    $.ajax({
        url: 'php_action/getOrderReport.php',
        type: 'POST',
        data: { period: period },
        dataType: 'json',
        success: function(response) {
            // Clear the existing chart if it exists
            clearChart();

            // Create a new chart with the received data
            createSalesChart(response);
        }
    });
});

// Function to clear the existing chart (if any)
function clearChart() {
    if (salesChart) {
        salesChart.destroy(); // Destroy the existing chart
        salesChart = null; // Reset the global chart instance
    }

    // Clear the canvas content
    var canvas = document.getElementById('salesChart');
    var ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height); // Clear the canvas
}

// Function to create the bar chart
function createSalesChart(data) {
    var labels = [];
    var salesData = [];

    // Process the data for the chart
    data.forEach(function(item) {
        if (item.year && item.month) {
            // Convert month number to month name
            var monthName = monthNames[item.month - 1]; // item.month is 1-based (1 for January, 2 for February)
            labels.push(monthName + ' ' + item.year); // For monthly data with formatted month name
            salesData.push(item.total_sales);
        } else if (item.week) {
            labels.push('Week ' + item.week + ' ' + item.year); // For weekly data
            salesData.push(item.total_sales);
        } else if (item.day) {
            labels.push(item.day); // For daily data
            salesData.push(item.total_sales);
        } else if (item.year) {
            labels.push(item.year); // For yearly data
            salesData.push(item.total_sales);
        }
    });

    // Create the chart
    var ctx = document.getElementById('salesChart').getContext('2d');
    salesChart = new Chart(ctx, {
        type: 'line', // Change to 'line' if you want a line chart
        data: {
            labels: labels,
            datasets: [{
                label: 'Total Sales',
                data: salesData,
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            responsive: true
        }
    });
}


</script>


<?php require_once 'includes/footer.php'; ?>